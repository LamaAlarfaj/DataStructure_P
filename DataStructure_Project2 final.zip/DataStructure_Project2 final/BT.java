package DataStructure_Project2;

public interface BT<K extends Comparable<K>, T> {
    // Check if the tree is empty
    boolean isEmpty();

    // Get the size (number of elements) in the tree
    int getSize();

    // Clear all elements from the tree
    void clearTree();

    // Get the current element in the tree
    T getCurrentElement();

    // Update the data of the current element
    void setCurrentElement(T e);

    // Search for an element with the given key
    boolean searchForKey(K key);

    // Insert a new element with the given key and data
    boolean addElement(K key, T data);

    // Remove the element with the given key
    boolean deleteElement(K key);

    // Get a linked list of all the data elements in the tree
    LinkedList<T> getDataList();

    // Get a linked list of all the keys in the tree
    LinkedList<K> getKeyList();

    // Perform an in-order traversal of the tree and print the keys
    void inOrderTraversal();

    // Perform a traversal of the tree, printing the data elements
    void traverseWithData();
}