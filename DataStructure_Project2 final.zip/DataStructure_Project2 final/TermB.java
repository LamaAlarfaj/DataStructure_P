package DataStructure_Project2;

public class TermB {
    String word;

    // with each word AVL Tree for the document Numbers with ranke
    // for each word in the documet it self
    BST <Integer, Integer> docIDS_ranked;

    public TermB() {
        word = "";
        docIDS_ranked = new BST <Integer, Integer> ();
    }

    public TermB(String word)
    {
        this.word = word;
        docIDS_ranked = new BST <Integer, Integer> ();
    }

    public void addDocumentID(int docID)
    {
        if (docIDS_ranked.isTreeEmpty())
            docIDS_ranked.addElement(docID, 1);
        else
        {
            if (docIDS_ranked.searchForKey(docID))
            {
                int ranked = docIDS_ranked.getCurrentValue();
                ranked++;
                docIDS_ranked.setCurrentValue(ranked);
            }
            else
                docIDS_ranked.addElement(docID, 1);
        }
    }

    public void setTerm(String word)
    {
        this. word = word;
    }

    public String getTerm()
    {
        return word;
    }

    public LinkedList<Integer> getDocumentIDs()
    {
        return docIDS_ranked.fetchKeys();
    }

    public LinkedList<Integer> getRankings()
    {
        return this.docIDS_ranked.fetchData();
    }

    @Override
    public String toString() {
        String docs = "";
        LinkedList<Integer> IDs = getDocumentIDs();
        IDs.moveToFirst();
        for (int i = 0, j = 0; i < IDs.getSize(); i++)
        {
            if ( i == 0)
                docs += " " + String.valueOf(i) ;
            else
                docs += ", " + String.valueOf(i) ;
            IDs.moveToNext();
        }
        return word + "[" + docs + ']';
    }

}
