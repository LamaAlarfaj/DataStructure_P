package DataStructure_Project2;

/*
Inverted Index with BSTs: Enhance the implementation of Inverted Index by using BSTs
instead of Lists.
 */

public class Inverted_Index_BST {
    class frequency
    {
        int docID = 0;
        int f = 0;
        String msg = "Document ";
    }

    BST <String, TermB> invertedindexBST;
    frequency [] freqs;

    //==========================================================================
    public Inverted_Index_BST() {
        invertedindexBST = new BST <String, TermB>();
        freqs = new frequency[50];
    }

    //==========================================================================
    public int size()
    {
        return invertedindexBST.getElementCount();
    }

    //==========================================================================
    public boolean addWord(int docID, String word)
    {
        if (invertedindexBST.isTreeEmpty())
        {
            TermB t = new TermB ();
            t.setTerm(word);
            t.addDocumentID(docID);
            invertedindexBST.addElement(word, t);
            return true;
        }
        else
        {
            if (invertedindexBST.searchForKey(word))
            {
                TermB t = invertedindexBST.getCurrentValue();
                t.addDocumentID(docID);
                invertedindexBST.setCurrentValue(t);
                return false;

            }

            TermB t = new TermB ();
            t.setTerm(word);
            t.addDocumentID(docID);
            invertedindexBST.addElement(word, t);
            return true;
        }
    }

    //=====================================================================
    public boolean containsWord(String word)
    {
        return invertedindexBST.searchForKey(word);
    }

    //=====================================================================
    public void printDocument()
    {
        invertedindexBST.inOrderTraversal();
    }
    //=====================================================================
    public LinkedList<Integer> executeAndOrQuery(String str )
    {
        if (! str.contains(" OR ") && ! str.contains(" AND "))
        {
            str = str.toLowerCase().trim();
            LinkedList<Integer> result = new LinkedList<Integer>();
            if (this.containsWord(str))
                result = invertedindexBST.getCurrentValue().getDocumentIDs();
            return result;
        }

        else if (str.contains(" OR ") && str.contains(" AND "))
        {

            String [] AND_ORs = str.split(" OR ");
            LinkedList<Integer> result = executeAndQuery(AND_ORs[0]);

            for ( int i = 1 ; i < AND_ORs.length ; i++  )
            {
                LinkedList<Integer> r2 = executeAndQuery(AND_ORs[i]);

                r2.moveToFirst();
                for (int j = 0; j < r2.getSize() ; j++)
                {
                    boolean found = false;
                    result.moveToFirst();
                    while ( ! result.isLast())
                    {
                        if (result.getCurrentData()== r2.getCurrentData())
                        {
                            found = true;
                            break;
                        }
                        result.moveToNext();
                    }
                    if (result.getCurrentData() == r2.getCurrentData())
                        found = true;

                    if (!found )
                        result.insertAfterCurrent(r2.getCurrentData());

                    r2.moveToNext();
                }
            }
            return result;
        }

        else  if (str.contains(" AND "))
            return executeAndQuery(str);

        return executeOrQuery(str);
    }

    //==========================================================================
    public LinkedList<Integer> executeAndQuery(String str)
    {
        String [] ANDs = str.split(" AND ");

        LinkedList<Integer> result = new LinkedList<Integer>();
        if (this.containsWord(ANDs[0].toLowerCase().trim()))
            result = invertedindexBST.getCurrentValue().docIDS_ranked.fetchKeys();


        for ( int i = 0 ; i< ANDs.length ; i++)
        {

            LinkedList<Integer> b1 = result;
            result = new LinkedList<Integer> ();

            if (this.containsWord(ANDs[i].toLowerCase().trim()))
            {
                LinkedList<Integer> docs = invertedindexBST.getCurrentValue().docIDS_ranked.fetchKeys();

                docs.moveToFirst();
                for ( int j = 0 ; j < docs.size ; j++)
                {
                    b1.moveToFirst();
                    boolean found =  false;
                    while ( ! b1.isLast())
                    {
                        if ( b1.getCurrentData()==docs.getCurrentData())
                        {
                            found = true;
                            break;
                        }
                        b1.moveToNext();
                    }
                    if ( b1.getCurrentData()== docs.getCurrentData())
                        found = true;

                    if (found)
                        result.insertAfterCurrent(docs.getCurrentData());

                    docs.moveToNext();
                }
            }
        }
        return result;
    }
    //==========================================================================
    public LinkedList<Integer> executeOrQuery(String str)
    {
        String [] ORs = str.split(" OR ");

        LinkedList<Integer> result =  new LinkedList<Integer> ();
        if (this.containsWord(ORs[0].toLowerCase().trim()))
            result = invertedindexBST.getCurrentValue().docIDS_ranked.fetchKeys();

        for ( int i = 1 ; i< ORs.length ; i++)
        {
            if (this.containsWord(ORs[i].toLowerCase().trim()))
            {
                LinkedList<Integer> docs = invertedindexBST.getCurrentValue().docIDS_ranked.fetchKeys();
                docs.moveToFirst();
                for ( int j = 0 ; j < docs.size ; j++)
                {
                    result.moveToFirst();
                    boolean found =  false;
                    while (! result.isLast())
                    {
                        if ( result.getCurrentData()== docs.getCurrentData())
                        {
                            found = true;
                            break;
                        }
                        result.moveToNext();
                    }
                    if ( result.getCurrentData() == docs.getCurrentData())
                        found = true;

                    if (! found)
                        result.insertAfterCurrent(docs.getCurrentData());

                    docs.moveToNext();
                }
            }
        }
        return result;
    }

    //=================================================================
    public void calculateTermFrequency(String str)
    {
        str = str.toLowerCase().trim();
        String [] words = str.split(" ");
        freqs = new frequency[50];
        for ( int i = 0 ; i < 50 ; i++ )
        {
            freqs[i] = new frequency();
            freqs[i].docID = i;
            freqs[i].f = 0;
            freqs[i].msg = "Document " + i + " : ";
        }

        for ( int i = 0 ; i < words.length ; i++)
        {
            if (invertedindexBST.searchForKey(words[i]))
            {
                LinkedList<Integer> docs = invertedindexBST.getCurrentValue().getDocumentIDs();
                LinkedList<Integer> rank = invertedindexBST.getCurrentValue().getRankings();

                docs.moveToFirst();
                rank.moveToFirst();
                for (int j = 0; j < docs.getSize() ; j ++)
                {
                    int index = docs.getCurrentData();
                    freqs[index].docID = index;
                    freqs[index].f += rank.getCurrentData();
                    freqs[index].msg +=" ( " + words[i] + ", " + rank.getCurrentData() + " ) +";
                    docs.moveToNext();
                    rank.moveToNext();
                }
            }
        }

        for ( int x = 0 ; x < freqs.length ; x ++)
        {
            freqs[x].msg = freqs[x].msg.substring(0, freqs[x].msg.length()-1);
            freqs[x].msg += " = " + freqs[x].f;
        }

        sortByTermFrequency(freqs, 0, freqs.length-1 );

        System.out.println("Results: ");

        for ( int x = 0 ;  freqs[x].f != 0 ; x++)
            System.out.println(freqs[x].msg);

        System.out.println("\nDocIDt\tScore");
        for ( int x = 0 ;  freqs[x].f != 0 ; x++)
            System.out.println(freqs[x].docID + "\t\t" + freqs[x].f);
    }

    //=================================================================
    public static void sortByTermFrequency(frequency [] A , int l , int r )
    {
        if ( l >= r )
            return;
        int m = ( l + r ) / 2;
        sortByTermFrequency(A , l , m ) ;          // Sort first half
        sortByTermFrequency(A , m + 1 , r ) ;    // Sort second half
        merge (A , l , m , r ) ;            // Merge
    }

    private static void merge ( frequency [] A , int l , int m , int r )
    {
        frequency [] B = new frequency [ r - l + 1];
        int i = l , j = m + 1 , k = 0;

        while ( i <= m && j <= r )
        {
            if ( A [ i ].f >= A [ j ].f)
                B [ k ++] = A [ i ++];
            else
                B [ k ++] = A [ j ++];
        }

        if ( i > m )
            while ( j <= r )
                B [ k ++] = A [ j ++];
        else
            while ( i <= m )
                B [ k ++] = A [ i ++];

        for ( k = 0; k < B . length ; k ++)
            A [ k + l ] = B [ k ];
    }

}
