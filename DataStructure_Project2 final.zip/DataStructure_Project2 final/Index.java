package DataStructure_Project2;

/**
 * Index: A mapping from document IDs to a list of words contained in the document.
 */

public class Index {
    class FrequencyInfo
    {
        int docID = 0;
        int f = 0;
        String msg = "Document ";
    }

    class Document {
        int docID;
        LinkedList <String> index;

        public Document() {
            docID = 0;
            index = new LinkedList <String>();
        }

        public void addWord(String word)
        {
            index.insertAfterCurrent(word);
        }

        public boolean containsWord(String word)
        {
            if (index.isEmpty())
                return false;

            index.moveToFirst();
            while ( ! index.isLast())
            {
                if ( index.getCurrentData().compareToIgnoreCase(word) == 0)
                    return true;
                index.moveToNext();
            }
            if ( index.getCurrentData().compareToIgnoreCase(word) == 0)
                return true;
            return false;
        }
    }
    //===========================================================

    Document [] indexes;
    FrequencyInfo[] freqs;


    public Index() {
        freqs = new FrequencyInfo[50];
        indexes = new Document [50];
        for ( int i = 0 ; i < indexes.length ; i++)
        {
            indexes [i] = new Document();
            indexes [i].docID = i;
        }
    }

    public void addDocument ( int docID, String data)
    {
        indexes[docID].addWord(data);
    }

    public void printDocment (int docID)
    {
        if ( indexes[docID].index.isEmpty())
            System.out.println("Empty Document");
        else
        {
            indexes[docID].index.moveToFirst();
            for ( int i = 0; i< indexes[docID].index.size ; i++)
            {
                System.out.print (indexes[docID].index.getCurrentData() + " ");
                indexes[docID].index.moveToNext();
            }
        }
    }
    //=================================================================
    public  boolean [] getDocumentIDs(String str)
    {
        boolean [] result = new boolean [50];
        for (int i = 0 ; i < 50 ; i++)
            result[i] = false;

        for (int i = 0 ; i < 50 ; i++)
            if (indexes[i].containsWord(str))
                result[i] = true;

        return result;
    }

    //=================================================================
    public LinkedList<Integer> executeAndOrQuery(String str )
    {
        if (! str.contains(" OR ") && ! str.contains(" AND "))
        {
            str = str.toLowerCase().trim();
            LinkedList<Integer> result = new LinkedList<Integer>();
            boolean [] docs = getDocumentIDs(str);
            for ( int i = 0 ; i < docs.length ; i++)
                if (docs[i])
                    result.insertAfterCurrent(i);
            return result;
        }

        else if (str.contains(" OR ") && str.contains(" AND "))
        {
            String [] AND_ORs = str.split(" OR ");
            LinkedList<Integer> result = AND_Function (AND_ORs[0]);

            for ( int i = 1 ; i < AND_ORs.length ; i++  )
            {
                LinkedList<Integer> r2 =AND_Function (AND_ORs[i]);

                r2.moveToFirst();
                for (int j = 0; j < r2.getSize() ; j++)
                {
                    boolean found = false;
                    result.moveToFirst();
                    while (! result.isLast())
                    {
                        if (result.getCurrentData().compareTo(r2.getCurrentData()) == 0 )
                            found = true;
                        result.moveToNext();
                    }
                    if (result.getCurrentData().compareTo(r2.getCurrentData()) == 0 )
                        found = true;

                    if (!found )
                        result.insertAfterCurrent(r2.getCurrentData());

                    r2.moveToNext();
                }
            }
            return result;
        }

        else  if (str.contains(" AND "))
            return AND_Function (str);

        return OR_Function (str);
    }

    //==========================================================================
    public LinkedList<Integer> AND_Function (String str)
    {
        String [] ANDs = str.split(" AND ");

        LinkedList<Integer> result = new LinkedList<Integer>();
        boolean [] docs = getDocumentIDs(ANDs[0].toLowerCase().trim());
        for ( int i = 0 ; i < docs.length ; i++)
            if (docs[i])
                result.insertAfterCurrent(i);

        for ( int i = 1 ; i< ANDs.length ; i++)
        {

            LinkedList<Integer> b1 = result;
            result = new LinkedList<Integer> ();

            docs = getDocumentIDs(ANDs[i].toLowerCase().trim());
            for ( int j = 0 ; j < docs.length ; j++)
            {
                if (docs[j] )  {
                    b1.moveToFirst();
                    boolean found =  false;
                    while ( ! b1.isLast())
                    {
                        if ( b1.getCurrentData()==j)
                        {
                            found = true;
                            break;
                        }
                        b1.moveToNext();
                    }
                    if ( b1.getCurrentData()== j)
                        found = true;
                    if (found)
                        result.insertAfterCurrent(j);
                }
            }
        }
        return result;
    }
    //==========================================================================
    public LinkedList<Integer> OR_Function (String str)
    {
        String [] ORs = str.split(" OR ");

        LinkedList<Integer> result = new LinkedList<Integer> ();
        boolean [] docs = getDocumentIDs(ORs[0].toLowerCase().trim());
        for ( int i = 0 ; i < docs.length ; i++)
            if (docs[i])
                result.insertAfterCurrent(i);

        for ( int i = 1 ; i< ORs.length ; i++)
        {
            docs = getDocumentIDs(ORs[i].toLowerCase().trim());
            for ( int j = 0 ; j < 50 ; j++)
            {
                if (docs[j] )  {

                    result.moveToFirst();
                    boolean found =  false;

                    while (! result.isLast() )
                    {
                        if ( result.getCurrentData() == j)
                            found = true;
                        result.moveToNext();
                    }
                    if ( result.getCurrentData() == j)
                        found = true;

                    if (! found)
                        result.insertAfterCurrent(j);
                }
            }
        }
        return result;
    }
    //=================================================================
    public void TF(String str)
    {
        str = str.toLowerCase().trim();
        String [] words = str.split(" ");
        freqs = new FrequencyInfo[50];
        for ( int i = 0 ; i < 50 ; i++ )
        {
            freqs[i] = new FrequencyInfo();
            freqs[i].docID = i;
            freqs[i].f = 0;
            freqs[i].msg = "Document " + i + " : ";
        }

        for ( int docs = 0 ; docs <50 ; docs++)
        {
            for ( int i = 0 ; i < words.length ; i++)
            {
                indexes[docs].index.moveToFirst();
                int wordcount = 0;
                for (int x = 0; x < indexes[docs].index.getSize() ; x++ )
                {
                    if (indexes[docs].index.getCurrentData().compareTo(words[i])==0)
                        wordcount ++;
                    indexes[docs].index.moveToNext();
                }
                freqs[docs].f += wordcount;
                freqs[docs].msg +=" ( " + words[i] + ", " + wordcount + " ) +";
            }
        }

        for ( int x = 0 ; x < freqs.length ; x ++)
        {
            freqs[x].msg = freqs[x].msg.substring(0, freqs[x].msg.length()-1);
            freqs[x].msg += " = " + freqs[x].f;
        }

        mergesort(freqs, 0, freqs.length-1 );

        System.out.println("Results: ");

        for ( int x = 0 ;  freqs[x].f != 0 ; x++)
            System.out.println(freqs[x].msg);

        System.out.println("\nDocIDt\tScore");
        for ( int x = 0 ;  freqs[x].f != 0 ; x++)
            System.out.println(freqs[x].docID + "\t\t" + freqs[x].f);
    }

    //=================================================================
    public static void mergesort (FrequencyInfo[] A , int l , int r )
    {
        if ( l >= r )
            return;
        int m = ( l + r ) / 2;
        mergesort (A , l , m ) ;          // Sort first half
        mergesort (A , m + 1 , r ) ;    // Sort second half
        merge (A , l , m , r ) ;            // Merge
    }

    private static void merge (FrequencyInfo[] A , int l , int m , int r )
    {
        FrequencyInfo[] B = new FrequencyInfo[ r - l + 1];
        int i = l , j = m + 1 , k = 0;

        while ( i <= m && j <= r )
        {
            if ( A [ i ].f >= A [ j ].f)
                B [ k ++] = A [ i ++];
            else
                B [ k ++] = A [ j ++];
        }

        if ( i > m )
            while ( j <= r )
                B [ k ++] = A [ j ++];
        else
            while ( i <= m )
                B [ k ++] = A [ i ++];

        for ( k = 0; k < B . length ; k ++)
            A [ k + l ] = B [ k ];
    }

}
