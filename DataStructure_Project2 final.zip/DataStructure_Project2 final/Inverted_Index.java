package DataStructure_Project2;

/*
Inverted Index: A mapping from terms (unique words) to a list of documents containing
those terms. Both of Index and Inverted Index will be implemented using list of lists.  */


public class Inverted_Index {
    class frequency
    {
        int docID = 0;
        int f = 0;
        String msg = "Document ";
    }

    frequency [] freqs;
    LinkedList <Term> invertedindex;

    //==========================================================================
    public Inverted_Index() {
        invertedindex = new LinkedList <Term>();
        freqs = new frequency [50];
    }

    //==========================================================================
    public int size()
    {
        return invertedindex.getSize();
    }

    //==========================================================================
    public boolean addWord(int docID, String word)
    {
        if (invertedindex.isEmpty())
        {
            Term t = new Term ();
            t.setTerm(word);
            t.addDocumentID(docID);
            invertedindex.insertAfterCurrent(t);
            return true;
        }
        else
        {
            invertedindex.moveToFirst();
            while ( ! invertedindex.isLast())
            {
                if ( invertedindex.getCurrentData().word.compareTo(word) == 0)
                {
                    Term t = invertedindex.getCurrentData();
                    t.addDocumentID(docID);
                    invertedindex.updateCurrentData(t);
                    return false;
                }
                invertedindex.moveToNext();
            }
            if ( invertedindex.getCurrentData().word.compareTo(word) == 0)
            {
                Term t = invertedindex.getCurrentData();
                t.addDocumentID(docID);
                invertedindex.updateCurrentData(t);
                return false;
            }
            Term t = new Term ();
            t.setTerm(word);
            t.addDocumentID(docID);
            invertedindex.insertAfterCurrent(t);
        }
        return true;
    }

    //==========================================================================
    public boolean containsWord(String word)
    {
        if (invertedindex.isEmpty())
            return false;

        invertedindex.moveToFirst();
        for ( int i = 0 ; i < invertedindex.size ; i++)
        {
            if ( invertedindex.getCurrentData().word.compareTo(word) == 0)
                return true;
            invertedindex.moveToNext();
        }
        return false;
    }
    //=====================================================================
    public LinkedList<Integer> executeAndOrQuery(String str )
    {
        if (! str.contains(" OR ") && ! str.contains(" AND "))
        {
            str = str.toLowerCase().trim();
            LinkedList<Integer> result = new LinkedList<Integer>();
            if (this.containsWord(str))
            {
                boolean [] docs = invertedindex.getCurrentData().getTerm();
                for ( int i = 0 ; i < docs.length ; i++)
                    if (docs[i])
                        result.insertAfterCurrent(i);
            }
            return result;
        }

        else if (str.contains(" OR ") && str.contains(" AND "))
        {
            String [] AND_ORs = str.split(" OR ");
            LinkedList<Integer> result = executeAndQuery(AND_ORs[0]);

            for ( int i = 1 ; i < AND_ORs.length ; i++  )
            {
                LinkedList<Integer> r2 = executeAndQuery(AND_ORs[i]);

                r2.moveToFirst();
                for (int j = 0; j < r2.getSize() ; j++)
                {
                    boolean found = false;
                    result.moveToFirst();
                    while (! result.isLast())
                    {
                        if (result.getCurrentData().compareTo(r2.getCurrentData()) == 0 )
                            found = true;
                        result.moveToNext();
                    }
                    if (result.getCurrentData().compareTo(r2.getCurrentData()) == 0 )
                        found = true;

                    if (!found )
                        result.insertAfterCurrent(r2.getCurrentData());

                    r2.moveToNext();
                }
            }
            return result;
        }

        else  if (str.contains(" AND "))
            return executeAndQuery(str);

        return executeOrQuery(str);
    }

    //==========================================================================
    public LinkedList<Integer> executeAndQuery(String str)
    {
        String [] ANDs = str.split(" AND ");

        LinkedList<Integer> result = new LinkedList<Integer>();
        if (this.containsWord(ANDs[0].toLowerCase().trim()))
        {
            boolean [] docs = invertedindex.getCurrentData().getTerm();
            for ( int i = 0 ; i < docs.length ; i++)
                if (docs[i])
                    result.insertAfterCurrent(i);
        }

        for ( int i = 1 ; i< ANDs.length ; i++)
        {
            LinkedList<Integer> b1 = result;
            result = new LinkedList<Integer> ();

            if (this.containsWord(ANDs[i].toLowerCase().trim()))
            {
                boolean [] docs = invertedindex.getCurrentData().getTerm();
                for ( int j = 0 ; j < docs.length ; j++)
                {
                    if (docs[j] )  {
                        b1.moveToFirst();
                        boolean found =  false;
                        while ( ! b1.isLast())
                        {
                            if ( b1.getCurrentData()==j)
                                found = true;
                            b1.moveToNext();
                        }

                        if ( b1.getCurrentData()== j)
                            found = true;

                        if (found)
                            result.insertAfterCurrent(j);
                    }
                }
            }
        }
        return result;
    }
    //==========================================================================
    public LinkedList<Integer> executeOrQuery(String str)
    {
        String [] ORs = str.split(" OR ");

        LinkedList<Integer> result = new LinkedList<Integer> ();
        if (this.containsWord(ORs[0].toLowerCase().trim()))
        {
            boolean [] docs = invertedindex.getCurrentData().getTerm();
            for ( int i = 0 ; i < docs.length ; i++)
                if (docs[i])
                    result.insertAfterCurrent(i);
        }
        for ( int i = 1 ; i< ORs.length ; i++)
        {
            if (this.containsWord(ORs[i].toLowerCase().trim()))
            {
                boolean [] docs = invertedindex.getCurrentData().getTerm();
                for ( int j = 0 ; j < docs.length ; j++)
                {
                    if (docs[j] )  {

                        result.moveToFirst();
                        boolean found =  false;

                        while (! result.isLast() )
                        {
                            if ( result.getCurrentData() == j)
                                found = true;
                            result.moveToNext();
                        }
                        if ( result.getCurrentData() == j)
                            found = true;

                        if (! found)
                            result.insertAfterCurrent(j);
                    }
                }
            }
        }
        return result;
    }

    //==========================================================================
    public void printDocment()
    {
        if (this.invertedindex.isEmpty())
            System.out.println("Empty Inverted Index");
        else
        {
            this.invertedindex.moveToFirst();
            while ( ! this.invertedindex.isLast())
            {
                System.out.println(invertedindex.getCurrentData());
                this.invertedindex.moveToNext();
            }
            System.out.println(invertedindex.getCurrentData());
        }
    }

    //=================================================================
    public void calculateTermFrequency(String str)
    {
        str = str.toLowerCase().trim();
        String [] words = str.split(" ");
        freqs = new frequency[50];
        for ( int i = 0 ; i < 50 ; i++ )
        {
            freqs[i] = new frequency();
            freqs[i].docID = i;
            freqs[i].f = 0;
            freqs[i].msg = "Document " + i + " : ";
        }

        for ( int i = 0 ; i < words.length ; i++)
        {
            if (containsWord(words[i]))
            {
                boolean [] docs = invertedindex.getCurrentData().getTerm();
                int [] rank = invertedindex.getCurrentData().getRankings();

                for ( int j = 0 ; j < docs.length ; j ++)
                {
                    if (docs[j] == true)
                    {
                        int index = j;
                        freqs[index].docID = index;
                        freqs[index].f += rank[j];
                        freqs[index].msg +=" ( " + words[i] + ", " + rank[j] + " ) +";
                    }
                }
            }
        }

        for ( int x = 0 ; x < freqs.length ; x ++)
        {
            freqs[x].msg = freqs[x].msg.substring(0, freqs[x].msg.length()-1);
            freqs[x].msg += " = " + freqs[x].f;
        }

        sortByTermFrequency(freqs, 0, freqs.length-1 );

        System.out.println("Results: ");

        for ( int x = 0 ;  freqs[x].f != 0 ; x++)
            System.out.println(freqs[x].msg);

        System.out.println("\nDocIDt\tScore");
        for ( int x = 0 ;  freqs[x].f != 0 ; x++)
            System.out.println(freqs[x].docID + "\t\t" + freqs[x].f);
    }

    //=================================================================
    public static void sortByTermFrequency(frequency [] A , int l , int r )
    {
        if ( l >= r )
            return;
        int m = ( l + r ) / 2;
        sortByTermFrequency(A , l , m ) ;          // Sort first half
        sortByTermFrequency(A , m + 1 , r ) ;    // Sort second half
        merge (A , l , m , r ) ;            // Merge
    }

    private static void merge ( frequency [] A , int l , int m , int r )
    {
        frequency [] B = new frequency [ r - l + 1];
        int i = l , j = m + 1 , k = 0;

        while ( i <= m && j <= r )
        {
            if ( A [ i ].f >= A [ j ].f)
                B [ k ++] = A [ i ++];
            else
                B [ k ++] = A [ j ++];
        }

        if ( i > m )
            while ( j <= r )
                B [ k ++] = A [ j ++];
        else
            while ( i <= m )
                B [ k ++] = A [ i ++];

        for ( k = 0; k < B . length ; k ++)
            A [ k + l ] = B [ k ];
    }



}
