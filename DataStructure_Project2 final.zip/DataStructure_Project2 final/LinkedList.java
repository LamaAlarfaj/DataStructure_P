package DataStructure_Project2;
/**

 * @param <T>
 */

public class LinkedList<T>{

    // class Node
    class Node<T> {
        public T data;
        public Node<T> next;
        public Node () {
            data = null;
            next = null;
        }
        public Node (T val) {
            data = val;
            next = null;
        }
        // Setters/Getters...

        public T getData() {
            return data;
        }

        public void setData(T data) {
            this.data = data;
        }

        public Node<T> getNext() {
            return next;
        }

        public void setNext(Node<T> next) {
            this.next = next;
        }

    }

    // class Linked List
    private Node<T> head;
    private Node<T> current;
    int size;

    public LinkedList () {
        head = current = null;
        size = 0 ;
    }
    public boolean isEmpty() {
        return head == null;
    }
    public int getSize()
    {
        return size;
    }

    public boolean isLast() {
        return current.next == null;
    }
    public boolean isFull() {
        return false;
    }
    public void moveToFirst() {
        current = head;
    }
    public void moveToNext() {
        current = current.next;
    }
    public T getCurrentData() {
        return current.data;
    }
    public void updateCurrentData(T val) {
        current.data = val;
    }

    public void insertAfterCurrent(T val) {
        Node<T> tmp;
        if (isEmpty()) {
            current = head = new Node<T> (val);
        }
        else {
            tmp = current.next;
            current.next = new Node<T> (val);
            current = current.next;
            current.next = tmp;
        }
        size++ ;
    }

    public void removeCurrent() {
        if (current == head) {
            head = head.next;
        }
        else {
            Node<T> tmp = head;

            while (tmp.next != current)
                tmp = tmp.next;

            tmp.next = current.next;
        }

        if (current.next == null)
            current = head;
        else
            current = current.next;
        size --;
    }
    public void printList()
    {
        if ( head == null)
            System.out.println("Empty data");
        else
        {
            Node<T> tmp = head;
            while ( tmp != null)
            {
                System.out.print(tmp.data + "  ");
                tmp = tmp.next;
            }

        }
        System.out.println("");
    }

}

