package DataStructure_Project2;

import java.util.Scanner;

public class Main {

    public static Scanner input = new Scanner (System.in);
    public static Search_Engine SE = new Search_Engine();



    public static int displayMainMenu()
    {
        System.out.println("1. Retrieve term. ");
        System.out.println("2. Boolean Retrieval. ");
        System.out.println("3. Ranked Retrieval.");
        System.out.println("4. Indexed Documents.");
        System.out.println("5. Indexed Tokens.");
        System.out.println("6. Exist.");

        System.out.println("enter choice");
        int choice = input.nextInt();
        return choice;
    }

    public static void retrieveTermMenu()
    {
        int choice1 ;
        System.out.println("################### Retrieval Term ####################");

        System.out.println("1. index");
        System.out.println("2. inverted index");
        System.out.println("3. inverted index using BST");
        System.out.println("4. inverted index using AVL");
        System.out.println("enter your choice");
        choice1 = input.nextInt();

        System.out.println("Enter Term :");
        String str = "";
        str = input.next();

        System.out.print("Result doc IDs: ");
        SE.retrieveTerm(str.trim().toLowerCase(), choice1 ).printList();
        System.out.println("\n");

    }

    public static void booleanRetrievalMenu()
    {
        int choice1 ;
        System.out.println("################### Boolean Retrieval ####################");

        System.out.println("1. index");
        System.out.println("2. inverted index");
        System.out.println("3. inverted index using BST");
        System.out.println("4. inverted index using AVL");
        System.out.println("enter your choice");
        choice1 = input.nextInt();

        System.out.println("Enter Question (using Only AND OR ):");
        System.out.println("");

        String str = input.nextLine();
        str = input.nextLine();

        System.out.println("Q#: " + str.trim());

        System.out.print("Result doc IDs: ");
        SE.performBooleanRetrieval(str.trim().toUpperCase(), choice1 ).printList();
        System.out.println("\n");
    }

    public static void rankedRetrievalMenu()
    {
        System.out.println("######## Ranked Retrieval ######## ");
        System.out.println("1. index");
        System.out.println("2. inverted index");
        System.out.println("3. inverted index using BST");
        System.out.println("4. inverted index using AVL");
        System.out.println("enter your choice");
        int choice2 = input.nextInt();

        System.out.println("Enter Question (using Only AND OR ):");
        String str = input.nextLine();
        str = input.nextLine();

        System.out.println("## Q: " + str);
        SE.performRankedRetrieval(str.trim().toUpperCase(), choice2);
        System.out.println("\n");
    }

    public static void indexedDocumentsMenu()
    {
        System.out.println("######## Indexed Documents ######## ");
        System.out.println("Indexed Documents " );
        SE.displayIndexedDocuments();
        System.out.println("");
    }

    public static void indexedTokensMenu()
    {
        System.out.println("######## Indexed Tokens ######## ");
        System.out.println("tokens " );
        SE.displayIndexedTokens();
        System.out.println("");
    }

    public static void main(String[] args) {

        SE.loadData("C:\\Users\\Lenovo\\Downloads\\data\\stop.txt", "C:\\Users\\Lenovo\\Downloads\\dataset.csv");
        // TODO code application logic here
        int choice;

        do {
            choice = displayMainMenu();
            System.out.println("choice");
            switch (choice)
            {
                //retrieve Term
                case 1:
                    retrieveTermMenu();
                    break;

                //Boolean Retrieval: to enter a Boolean query that will return a set of unranked documents
                case 2:
                    booleanRetrievalMenu();
                    break;

                //Ranked Retrieval: to enter a query that will return a ranked list of documents with their scores
                case 3:
                    rankedRetrievalMenu();
                    break;

                //Indexed Documents: to show number of documents in the index
                case 4:
                    indexedDocumentsMenu();
                    break;

                //Indexed Tokens: to show number of vocabulary and tokens in the index
                case 5:
                    indexedTokensMenu();
                    break;

                case 6:
                    break;

                default:
                    System.out.println("bad choice, try again!");
            }
        } while (choice != 6);
    }

}